﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Player : MonoBehaviour
{
    private     Rigidbody       _rigidbody;
    public      Animator        _animator;
    public      GameObject      cameraBase;
    public      GameObject      attackPoint;
    public      Image           hpbar;

    private     bool            IsAttack            =   false;
    private     bool            IsJump              =   false;
    private     bool            end                 =   false;//나중에 게임매니저로 이동

    public      float           maxHP;

    private     float           HP { get; set; }
    private     float           AttackPower { get; set; }
    private     float           movSpeed { get; set; }


    void Start()
    {
        _rigidbody = gameObject.GetComponent<Rigidbody>();

        HP = 20.0f;
        AttackPower = 5.0f;
        movSpeed = 20.0f;

        maxHP = HP;
    }

    // Update is called once per frame
    void Update()
    {
        if (!end)//사망상태가 아닐시
        {
            if (Input.GetMouseButtonDown(0) && IsAttack == false)
            {
                StartCoroutine(Attack(AttackPower));
            }
            else if (Input.GetMouseButtonDown(1) && IsAttack == false)//동시입력 방지 else
            {
                //StartCoroutine(Skill_1(AttackPower));
            }

            if (IsAttack == false)//공격상태가 아닐시
            {
                if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.D))
                {
                    Move();//이동
                }
                else//가만히 있을경우
                {
                    _animator.SetBool("IsMove", false);
                }
            }

            if (Input.GetKeyDown(KeyCode.Space) && IsJump == false)//점프
            {
                IsJump = true;
                Jump();
            }
        }
    }

    void Jump()//점프
    {
        float JumpPow = Input.GetAxis("Jump");
        _rigidbody.AddForce(Vector3.up * JumpPow * 5.0f, ForceMode.Impulse);
    }

    void Move()//플레이어 이동
    {
        _animator.SetBool("IsMove", true);
        float Horizontal = Input.GetAxisRaw("Horizontal");
        float Vertical = Input.GetAxisRaw("Vertical");

        Vector3 mov = new Vector3(Horizontal, 0, Vertical);
        
        mov = mov.normalized * Time.deltaTime * movSpeed;

        Quaternion v3Rotation = Quaternion.Euler(0f, cameraBase.transform.rotation.eulerAngles.y, 0f);
        Vector3 v3RotatedDirection = v3Rotation * mov;

        if (mov != Vector3.zero)
        {
            Rot_dir(v3RotatedDirection);//이동방향으로 회전
        }
        
        _rigidbody.MovePosition(transform.position + v3RotatedDirection);
    }
    private void Rot_dir(Vector3 targetPos)//플레이어 회전
    {
        Quaternion targetRot = Quaternion.LookRotation(-targetPos);
        Quaternion frameRot = Quaternion.RotateTowards(transform.rotation,
                                                       targetRot, 540f * Time.deltaTime);

        transform.rotation = frameRot;
    }

    IEnumerator Attack(float AttackPower)//공격코루틴
    {
        IsAttack = true;
        _animator.SetBool("IsAttack", true);

        yield return new WaitForSeconds(0.4f);

        Collider[] colliders = Physics.OverlapSphere(transform.position, 2.3f);

        foreach (Collider col in colliders)
        {
            if (col.tag == "monster")
            {
                col.GetComponent<EnemyBase>().GetDam(AttackPower);
                break;
            }
        }

        yield return new WaitForSeconds(0.3f);

        IsAttack = false;
        _animator.SetBool("IsAttack", false);
    }
    IEnumerator Skill_1(float AttackPower)//스킬1 휘두르기
    {
        IsAttack = true;
        _animator.SetBool("IsSkill_1", true);

        yield return new WaitForSeconds(0.7f);

        yield return new WaitForSeconds(0.5f);

        IsAttack = false;
        _animator.SetBool("IsSkill_1", false);
    }

    private void OnCollisionEnter(Collision collision)
    {
        if(collision.transform.tag == "Ground")
        {
            IsJump = false;
        }
    }
    public void GetDam(float amount)
    {
        HP -= amount;

        hpbar.fillAmount = HP / maxHP;

        if (HP <= 0)
        {
            end = true;
            _animator.SetBool("IsDie", true);
        }
    }

}

